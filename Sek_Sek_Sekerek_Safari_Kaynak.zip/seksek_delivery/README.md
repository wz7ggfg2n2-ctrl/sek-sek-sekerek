# Sek Sek Sekerek (Android + iOS)

This folder is the shared Flutter implementation. The original Android-only project remains in the repository root; open this folder to work on the cross-platform app.

## Android

Install Flutter 3.47 or newer and the Flutter/Dart Android Studio plugins. Open this folder in Android Studio, run `flutter pub get`, then run on an Android device or emulator.

Debug APK: `build/app/outputs/flutter-apk/app-debug.apk`.

## iOS

Building and running iOS requires macOS and Xcode. On a Mac, run `flutter pub get` in this folder, then `flutter run` with an iOS Simulator or connected iPhone. Use a physical iPhone to verify tilt controls. A free Apple account supports local device testing; App Store distribution requires Apple Developer Program membership.