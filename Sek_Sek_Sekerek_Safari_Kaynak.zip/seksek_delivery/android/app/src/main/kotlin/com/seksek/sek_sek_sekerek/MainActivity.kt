package com.seksek.sek_sek_sekerek

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
