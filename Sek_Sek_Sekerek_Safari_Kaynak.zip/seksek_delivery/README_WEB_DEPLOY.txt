SEK SEK SEKEREK - iPhone Safari Web Build

This is the patched Flutter project. On web, the paddle is controlled by dragging a finger left/right; native iOS/Android keeps accelerometer tilt controls.

GitHub Pages deployment workflow is in .github/workflows/deploy.yml.

To deploy:
1. Create a NEW GitHub repository (public is the simplest free GitHub Pages option).
2. Upload the contents of this folder to the repository root, including the hidden .github folder.
3. In GitHub: Settings > Pages > Build and deployment > Source: GitHub Actions.
4. Open Actions and run the workflow (or push a commit).
5. When deployment finishes, open https://YOUR-USERNAME.github.io/REPOSITORY-NAME/ on iPhone Safari.
6. Safari Share > Add to Home Screen to make an app-like icon.

No Apple Developer membership or Mac is needed for this web version. The workflow uses GitHub Actions and GitHub Pages; free availability/limits depend on the GitHub account and repository settings.
