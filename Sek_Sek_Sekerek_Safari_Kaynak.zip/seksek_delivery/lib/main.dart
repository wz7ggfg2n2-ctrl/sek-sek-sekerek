import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const SekSekApp());
}

class SekSekApp extends StatelessWidget {
  const SekSekApp({super.key});

  @override
  Widget build(BuildContext context) => const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: GamePage(),
      );
}

enum Page { splash, home, settings, modes, game }

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> with SingleTickerProviderStateMixin {
  late final AnimationController _clock;
  StreamSubscription<AccelerometerEvent>? _sensor;
  SharedPreferences? _prefs;
  Page _page = Page.splash;
  Page? _previousPage;
  int _mode = 0; // 0 standard, 1 bouncy
  int _sensitivity = 1;
  int _score = 0;
  int _finalScore = 0;
  int _bestStandard = 0;
  int _bestBouncy = 0;
  bool _dark = false;
  bool _modeSelected = false;
  bool _paused = false;
  bool _gameOver = false;
  bool _calibrationPending = false;
  bool _calibrated = false;
  bool _sessionAngleCaptured = false;
  double _neutralAngle = 0;
  double _touchPaddleX = .5;
  double _angle = 0;
  double _ballX = .5;
  double _ballY = .38;
  double _vx = .14;
  double _vy = .32;
  double _paddleX = .5;
  double _lastFrame = 0;
  double _introTime = 0;
  double _gameStartedAt = 0;
  double _hintAlpha = 0;
  double _pageTransition = 1;
  double _gameOverTransition = 1;
  final List<_Confetti> _confetti = [];
  ui.Image? _logo;

  int get _best => _mode == 0 ? _bestStandard : _bestBouncy;

  @override
  void initState() {
    super.initState();
    _clock = AnimationController(vsync: this, duration: const Duration(days: 1))
      ..addListener(_tick)
      ..repeat();
    _startSensor();
    _loadPreferences();
    _loadLogo();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _prefs = prefs;
      _bestStandard = prefs.getInt('best_score_standard') ?? prefs.getInt('best_score') ?? 0;
      _bestBouncy = prefs.getInt('best_score_bouncy') ?? 0;
      _sensitivity = prefs.getInt('tilt_sensitivity') ?? 1;
      _dark = prefs.getBool('dark_theme') ?? false;
      _calibrated = prefs.getBool('tilt_calibrated') ?? false;
      _neutralAngle = prefs.getDouble('neutral_tilt') ?? 0;
    });
  }

  Future<void> _loadLogo() async {
    try {
      final data = await rootBundle.load('assets/fj_games_logo.jpeg');
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      if (mounted) setState(() => _logo = frame.image);
    } catch (_) {
      // A missing optional logo does not prevent the game from starting.
    }
  }

  void _startSensor() {
    // Safari/web uses touch-drag control; device-motion permission is not required.
    if (kIsWeb) return;
    _sensor = accelerometerEventStream(samplingPeriod: const Duration(milliseconds: 20)).listen((event) {
      final measured = -math.atan2(event.x, event.y);
      if (_calibrationPending) {
        setState(() {
          _neutralAngle = measured;
          _angle = measured;
          _calibrated = true;
          _calibrationPending = false;
        });
        _prefs?.setDouble('neutral_tilt', measured);
        _prefs?.setBool('tilt_calibrated', true);
        return;
      }
      _angle = measured;
      if (_page == Page.game && !_calibrated && !_sessionAngleCaptured) {
        _neutralAngle = measured;
        _sessionAngleCaptured = true;
      }
    }, onError: (_) {});
  }

  void _tick() {
    final now = _clock.lastElapsedDuration?.inMicroseconds.toDouble() ?? 0;
    final seconds = now / 1000000;
    _introTime = seconds;
    if (_page == Page.splash) {
      if (seconds >= 2.8) {
        _changePage(Page.home);
      }
    }

    if (_previousPage != null) {
      _pageTransition = math.min(1.0, _pageTransition + .055).toDouble();
      if (_pageTransition >= 1) _previousPage = null;
    }

    if (_page == Page.game && !_paused && !_gameOver) {
      final dt = (_lastFrame == 0 ? 0.016 : ((seconds - _lastFrame).clamp(0, .025))).toDouble();
      _lastFrame = seconds;
      _step(dt);
      final hintElapsed = seconds - _gameStartedAt - .35;
      _hintAlpha = hintElapsed < 0 ? 0.0 : hintElapsed < 1.65 ? 1.0 :
          (hintElapsed < 2 ? (2 - hintElapsed) / .35 : 0.0);
    } else {
      _hintAlpha = 0;
    }
    if (_gameOver && _gameOverTransition < 1) {
      _gameOverTransition = math.min(1.0, _gameOverTransition + .045).toDouble();
    }
    for (final bit in _confetti) {
      bit.y += bit.speed * .016;
      bit.rotation += .08;
    }
    _confetti.removeWhere((bit) => bit.y > 1.1);
    if (mounted) setState(() {});
  }

  void _step(double dt) {
    if (kIsWeb) {
      _paddleX += (_touchPaddleX - _paddleX) * .42;
    } else {
      final difference = _wrapAngle(_angle - _neutralAngle);
      final degrees = _sensitivity == 0 ? 45 : (_sensitivity == 2 ? 22 : 32);
      final normalized = (difference / (degrees * math.pi / 180)).clamp(-1.0, 1.0).toDouble();
      final target = .5 + normalized * .5;
      _paddleX += (target - _paddleX) * .28;
    }

    _ballX += _vx * dt;
    _ballY += _vy * dt;
    if (_ballX < .025) {
      _ballX = .025;
      _vx = _vx.abs();
      if (_mode == 1) _speedUp();
    }
    if (_ballX > .975) {
      _ballX = .975;
      _vx = -_vx.abs();
      if (_mode == 1) _speedUp();
    }
    if (_ballY < .025) {
      _ballY = .025;
      _vy = _vy.abs();
      if (_mode == 1) _speedUp();
    }

    final paddleY = .84;
    final paddleHalfWidth = .14;
    if (_vy > 0 && _ballY >= paddleY - .025 && _ballY <= paddleY + .025 &&
        (_ballX - _paddleX).abs() <= paddleHalfWidth + .025) {
      _ballY = paddleY - .05;
      _vy = -_vy.abs();
      _vx = (_vx + ((_ballX - _paddleX) / paddleHalfWidth) * .12).clamp(-.7, .7).toDouble();
      _score++;
      if (_score > _best) {
        if (_mode == 0) {
          _bestStandard = _score;
          _prefs?.setInt('best_score_standard', _bestStandard);
          _prefs?.setInt('best_score', _bestStandard);
        } else {
          _bestBouncy = _score;
          _prefs?.setInt('best_score_bouncy', _bestBouncy);
        }
      }
      if (_score == 1) {
        final speed = math.sqrt(_vx * _vx + _vy * _vy);
        const targetSpeed = .53;
        _vx *= targetSpeed / speed;
        _vy *= targetSpeed / speed;
      }
      if (_score % 10 == 0) {
        _vx *= 1.12;
        _vy *= 1.12;
      }
      if (_score == 50) _spawnConfetti(24);
      if (_score == 100) _spawnConfetti(90);
    }

    if (_ballY >= .99) {
      _finalScore = _score;
      _score = 0;
      _gameOver = true;
      _gameOverTransition = 0;
    }
  }

  void _speedUp() {
    _vx *= 1.08;
    _vy *= 1.08;
    final speed = math.sqrt(_vx * _vx + _vy * _vy);
    const maxSpeed = 3.2;
    if (speed > maxSpeed) {
      _vx *= maxSpeed / speed;
      _vy *= maxSpeed / speed;
    }
  }

  double _wrapAngle(double value) {
    while (value > math.pi) value -= 2 * math.pi;
    while (value < -math.pi) value += 2 * math.pi;
    return value;
  }

  void _spawnConfetti(int count) {
    final random = math.Random();
    for (var i = 0; i < count; i++) {
      _confetti.add(_Confetti(random.nextDouble(), -.1 - random.nextDouble(),
          .35 + random.nextDouble() * .5, random.nextInt(5)));
    }
  }

  void _changePage(Page next) {
    _previousPage = _page;
    _page = next;
    _pageTransition = 0;
    _lastFrame = 0;
    _gameStartedAt = (_clock.lastElapsedDuration?.inMicroseconds ?? 0) / 1000000;
  }

  void _startGame({bool transition = false}) {
    _score = 0;
    _finalScore = 0;
    _gameOver = false;
    _paused = false;
    _ballX = .5;
    _ballY = .38;
    _vx = (math.Random().nextBool() ? 1 : -1) * .14;
    _vy = .32;
    _paddleX = .5;
    _sessionAngleCaptured = false;
    if (!_calibrated) _neutralAngle = _angle;
    _gameStartedAt = (_clock.lastElapsedDuration?.inMicroseconds ?? 0) / 1000000;
    if (transition) {
      _changePage(Page.game);
    } else {
      _lastFrame = 0;
    }
  }

  Rect _rect(Size s, double l, double t, double r, double b) =>
      Rect.fromLTRB(s.width * l, s.height * t, s.width * r, s.height * b);

  void _movePaddle(Offset point, Size size) {
    if (kIsWeb && _page == Page.game && !_paused && !_gameOver) {
      _touchPaddleX = (point.dx / size.width).clamp(.08, .92).toDouble();
    }
  }

  void _tap(Offset point, Size size) {
    bool inRect(double l, double t, double r, double b) =>
        _rect(size, l, t, r, b).contains(point);
    switch (_page) {
      case Page.splash:
        break;
      case Page.home:
        if (inRect(.18, .275, .82, .365)) _changePage(Page.modes);
        if (inRect(.18, .395, .82, .485)) _changePage(Page.settings);
        break;
      case Page.settings:
        if (inRect(.08, .055, .29, .105)) _changePage(Page.home);
        else if (inRect(.08, .585, .48, .655)) {
          _dark = false;
          _prefs?.setBool('dark_theme', false);
        } else if (inRect(.52, .585, .92, .655)) {
          _dark = true;
          _prefs?.setBool('dark_theme', true);
        } else if (inRect(.08, .34, .92, .43)) {
          final gap = size.width * .025;
          final side = (size.width * .84 - gap * 2) / 3;
          _sensitivity = ((point.dx - size.width * .08) / (side + gap)).floor().clamp(0, 2).toInt();
          _prefs?.setInt('tilt_sensitivity', _sensitivity);
        } else if (inRect(.18, .745, .82, .815)) {
          _calibrationPending = true;
        }
        break;
      case Page.modes:
        if (inRect(.08, .055, .29, .105)) {
          _changePage(Page.home);
        } else if (inRect(.18, .295, .82, .38)) {
          _mode = 0;
          _modeSelected = true;
        } else if (inRect(.18, .41, .82, .495)) {
          _mode = 1;
          _modeSelected = true;
        } else if (_modeSelected && inRect(.18, .64, .82, .715)) {
          _startGame(transition: true);
        }
        break;
      case Page.game:
        if (_paused) {
          if (inRect(.08, .055, .29, .105)) {
            _paused = false;
            _gameOver = false;
            _changePage(Page.home);
          } else if (inRect(.18, .52, .82, .61)) {
            _paused = false;
            _lastFrame = 0;
          }
        } else if (_gameOver) {
          if (inRect(.18, .55, .82, .625)) _startGame();
          else if (inRect(.18, .655, .82, .73)) {
            _gameOver = false;
            _changePage(Page.home);
          }
        } else if (inRect(.08, .055, .29, .105)) {
          _gameOver = false;
          _changePage(Page.home);
        } else if (inRect(.70, .055, .92, .105)) {
          _paused = true;
        }
        break;
    }
    setState(() {});
  }

  @override
  void dispose() {
    _sensor?.cancel();
    _clock.dispose();
    _logo?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: LayoutBuilder(builder: (context, constraints) {
          final size = Size(constraints.maxWidth, constraints.maxHeight);
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (event) => _tap(event.localPosition, size),
            onPanDown: (event) => _movePaddle(event.localPosition, size),
            onPanUpdate: (event) => _movePaddle(event.localPosition, size),
            child: CustomPaint(
              size: size,
              painter: _GamePainter(
                page: _page,
                mode: _mode,
                sensitivity: _sensitivity,
                score: _score,
                finalScore: _finalScore,
                bestStandard: _bestStandard,
                bestBouncy: _bestBouncy,
                best: _best,
                dark: _dark,
                modeSelected: _modeSelected,
                paused: _paused,
                gameOver: _gameOver,
                calibrationPending: _calibrationPending,
                calibrated: _calibrated,
                ballX: _ballX,
                ballY: _ballY,
                paddleX: _paddleX,
                confetti: _confetti,
                logo: _logo,
                introTime: _introTime,
                hintAlpha: _hintAlpha,
                pageProgress: _pageTransition,
                gameOverProgress: _gameOverTransition,
              ),
            ),
          );
        }),
      );
}

class _Confetti {
  _Confetti(this.x, this.y, this.speed, this.color)
      : rotation = 0;
  double x, y, speed, rotation;
  final int color;
}

class _GamePainter extends CustomPainter {
  _GamePainter({
    required this.page,
    required this.mode,
    required this.sensitivity,
    required this.score,
    required this.finalScore,
    required this.bestStandard,
    required this.bestBouncy,
    required this.best,
    required this.dark,
    required this.modeSelected,
    required this.paused,
    required this.gameOver,
    required this.calibrationPending,
    required this.calibrated,
    required this.ballX,
    required this.ballY,
    required this.paddleX,
    required this.confetti,
    required this.logo,
    required this.introTime,
    required this.hintAlpha,
    required this.pageProgress,
    required this.gameOverProgress,
  });

  final Page page;
  final int mode, sensitivity, score, finalScore, bestStandard, bestBouncy, best;
  final bool dark, modeSelected, paused, gameOver, calibrationPending, calibrated;
  final double ballX, ballY, paddleX, introTime, pageProgress, gameOverProgress, hintAlpha;
  final List<_Confetti> confetti;
  final ui.Image? logo;

  final Paint _p = Paint()..isAntiAlias = true;
  late Canvas _canvas;
  late Size _size;
  double get w => _size.width;
  double get h => _size.height;
  Color get ink => dark ? const Color(0xFF73F5FF) : const Color(0xFF17634C);
  Color get accent => dark ? const Color(0xFFFF4FA3) : const Color(0xFFFFD166);

  @override
  void paint(Canvas canvas, Size size) {
    _canvas = canvas;
    _size = size;
    canvas.save();
    if (page != Page.splash && pageProgress < 1) {
      final eased = pageProgress * pageProgress * (3 - 2 * pageProgress);
      canvas.translate(0, h * .012 * (1 - eased));
      canvas.translate(w / 2, h / 2);
      canvas.scale(.992 + .008 * eased, .992 + .008 * eased);
      canvas.translate(-w / 2, -h / 2);
    }
    if (page == Page.splash) {
      _drawSplash();
      canvas.restore();
      return;
    }
    if (page == Page.game) {
      _drawGameBackground();
      _drawGame();
    } else {
      _drawHomeBackground();
      switch (page) {
        case Page.home:
          _drawHome();
          break;
        case Page.settings:
          _drawSettings();
          break;
        case Page.modes:
          _drawModes();
          break;
        case Page.splash:
        case Page.game:
          break;
      }
    }
    if (pageProgress < 1) {
      _p.color = Colors.black.withValues(alpha: (1 - pageProgress) * .07);
      _p.style = PaintingStyle.fill;
      canvas.drawRect(Offset.zero & size, _p);
    }
    canvas.restore();
  }

  void _drawSplash() {
    _p.color = Colors.white;
    _canvas.drawRect(Offset.zero & _size, _p);
    if (logo == null) return;
    final alpha = introTime < .8 ? introTime / .8 :
        introTime < 1.85 ? 1.0 : ((2.8 - introTime) / .95).clamp(0.0, 1.0);
    final side = math.min(w * .94, h * .78);
    _p.color = Colors.white.withValues(alpha: alpha.toDouble());
    _p.filterQuality = FilterQuality.high;
    _canvas.drawImageRect(logo!, Rect.fromLTWH(0, 0, logo!.width.toDouble(), logo!.height.toDouble()),
        Rect.fromLTWH((w - side) / 2, (h - side) / 2, side, side), _p);
  }

  void _drawHomeBackground() {
    final sky = dark ? const Color(0xFF151431) : const Color(0xFF86DDF4);
    _p.shader = ui.Gradient.linear(Offset.zero, Offset(0, h), [sky, dark ? const Color(0xFF35214D) : const Color(0xFFC7F2E0)]);
    _canvas.drawRect(Offset.zero & _size, _p);
    _p.shader = null;
    final t = introTime;
    _drawSun(w * .78, h * .20, math.min(w, h) * .075);
    _drawCloud(w * (.20 + .025 * math.sin(t * .4)), h * .19, w * .16);
    _drawCloud(w * (.70 - .018 * math.sin(t * .3)), h * .31, w * .11);
    _hill(h * .52, dark ? const Color(0xFF3A2B60) : const Color(0xFF80C987), .31, .025);
    _hill(h * .63, dark ? const Color(0xFF2A3157) : const Color(0xFF4EA96A), .18, .035);
    _p.color = dark ? const Color(0xFF202C4B) : const Color(0xFF329253);
    _canvas.drawRect(Rect.fromLTWH(0, h * .61, w, h * .39), _p);
    for (var i = 0; i < 12; i++) {
      final x = w * ((i * .083 + .018) % 1);
      _flower(x, h * (.78 + .12 * math.sin(i * 5.4)), w * .012, t + i);
    }
  }

  void _drawGameBackground() {
    _p.shader = ui.Gradient.linear(Offset.zero, Offset(0, h), [
      dark ? const Color(0xFF171531) : const Color(0xFF8DE4F6),
      dark ? const Color(0xFF311D49) : const Color(0xFFC7EFC8),
    ]);
    _canvas.drawRect(Offset.zero & _size, _p);
    _p.shader = null;
    _drawSun(w * .80, h * .16, w * .06);
    _hill(h * .38, dark ? const Color(0xFF483267) : const Color(0xFF91CF86), .25, .015);
    _hill(h * .53, dark ? const Color(0xFF2C2B53) : const Color(0xFF56A96E), .12, .02);
    _p.color = dark ? const Color(0xFF1C2945) : const Color(0xFF399453);
    _canvas.drawRect(Rect.fromLTWH(0, h * .53, w, h * .47), _p);
    for (var i = 0; i < 9; i++) {
      _flower(w * ((i * .119 + .04) % 1), h * (.66 + .27 * (i % 3) / 3), w * .009, i.toDouble());
    }
  }

  void _drawSun(double x, double y, double radius) {
    _p.color = dark ? const Color(0xFFFF70B7).withValues(alpha: .22) : const Color(0xFFFFE28A).withValues(alpha: .28);
    _canvas.drawCircle(Offset(x, y), radius * 1.8, _p);
    _p.color = dark ? const Color(0xFFFF9B75) : const Color(0xFFFFD85E);
    _canvas.drawCircle(Offset(x, y), radius, _p);
    _p.color = dark ? const Color(0xFFFFD166) : const Color(0xFFFFF2B8);
    _canvas.drawCircle(Offset(x - radius * .25, y - radius * .28), radius * .68, _p);
  }

  void _drawCloud(double x, double y, double width) {
    _p.color = dark ? const Color(0xFF55466F) : const Color(0xFFEFFFFF).withValues(alpha: .83);
    final path = Path()
      ..moveTo(x - width * .5, y + width * .12)
      ..cubicTo(x - width * .53, y - width * .02, x - width * .39, y - width * .08, x - width * .28, y - width * .04)
      ..cubicTo(x - width * .19, y - width * .31, x + width * .12, y - width * .29, x + width * .20, y - width * .04)
      ..cubicTo(x + width * .43, y - width * .11, x + width * .56, y + width * .02, x + width * .48, y + width * .14)
      ..close();
    _canvas.drawPath(path, _p);
  }

  void _hill(double base, Color color, double amplitude, double phase) {
    _p.color = color;
    final path = Path()..moveTo(0, base);
    path.cubicTo(w * .22, base - h * amplitude, w * .35, base + h * phase, w * .55, base - h * amplitude * .35);
    path.cubicTo(w * .75, base - h * amplitude * 1.3, w * .86, base + h * phase, w, base - h * amplitude * .2);
    path.lineTo(w, h);
    path.lineTo(0, h);
    path.close();
    _canvas.drawPath(path, _p);
  }

  void _flower(double x, double y, double r, double time) {
    final sway = math.sin(time * .7) * r * .7;
    _p.color = dark ? const Color(0xFF72DFD4) : const Color(0xFF237B43);
    _p.strokeWidth = math.max(1.5, r * .22).toDouble();
    _p.strokeCap = StrokeCap.round;
    _canvas.drawLine(Offset(x, y), Offset(x + sway, y - r * 3), _p);
    _p.color = dark ? const Color(0xFFFF7BC5) : const Color(0xFFFFD85E);
    for (var petal = 0; petal < 5; petal++) {
      final a = petal * math.pi * 2 / 5;
      _canvas.drawCircle(Offset(x + sway + math.cos(a) * r, y - r * 3 + math.sin(a) * r), r * .65, _p);
    }
    _p.color = Colors.white;
    _canvas.drawCircle(Offset(x + sway, y - r * 3), r * .34, _p);
  }

  void _drawHome() {
    _text('Sen ne kadar sekeceksin?', h * .22, w * .047, Colors.white, bold: false);
    _button(.18, .275, .82, .365, 'OYNA', primary: true);
    _button(.18, .395, .82, .485, 'AYARLAR');
    _button(.24, .895, .76, .945,
        'STANDART: $bestStandard  |  BOUNCY: $bestBouncy', small: true, darkPill: true);
  }

  void _drawSettings() {
    _back();
    _heading('AYARLAR', .17);
    _label('RAKET EĞİM HASSASİYETİ', .27);
    _button(.08, .34, .35, .43, 'DÜŞÜK', selected: sensitivity == 0);
    _button(.365, .34, .635, .43, 'NORMAL', selected: sensitivity == 1);
    _button(.65, .34, .92, .43, 'YÜKSEK', selected: sensitivity == 2);
    _label('Yüksek hassasiyet için telefonu daha az eğ', .47, small: true);
    _label('Düşük hassasiyet için daha fazla eğ', .50, small: true);
    _label('RENK MODU', .565);
    _button(.08, .585, .48, .655, 'PARLAK', selected: !dark);
    _button(.52, .585, .92, .655, 'KOYU', selected: dark);
    _label('HAREKET KALİBRASYONU', .705);
    _button(.18, .745, .82, .815, 'AÇIYI KALİBRE ET');
    _label(calibrationPending ? 'Telefonu istediğin açıda sabit tut...' :
        (calibrated ? 'Kalibrasyon kaydedildi' : 'Henüz kalibre edilmedi'), .835, small: true);
  }

  void _drawModes() {
    _back();
    _heading('MOD SEÇ', .17);
    _label('Nasıl oynamak istersin?', .235);
    _button(.18, .295, .82, .38, 'STANDART', selected: modeSelected && mode == 0);
    _button(.18, .41, .82, .495, 'BOUNCY MOD', selected: modeSelected && mode == 1);
    _label(!modeSelected ? 'Bir mod seç' : (mode == 1 ? 'Zıpzıp Top' : 'Standart Sektirme'), .535, small: true);
    _button(.18, .64, .82, .715, 'OYUNA BAŞLA', primary: modeSelected);
  }

  void _drawGame() {
    _button(.08, .055, .29, .105, 'MENÜ');
    if (!gameOver && !paused) _button(.70, .055, .92, .105, 'DURAKLAT', small: true);
    _p.color = Colors.white.withValues(alpha: .12);
    _p.strokeWidth = 2;
    _canvas.drawLine(Offset(w * .12, h * .5), Offset(w * .88, h * .5), _p);
    for (final bit in confetti) {
      _p.color = [const Color(0xFFFFD166), const Color(0xFFFF6B6B), const Color(0xFF70D6FF), const Color(0xFFB7E4C7), const Color(0xFFC77DFF)][bit.color];
      _canvas.save();
      _canvas.translate(w * bit.x, h * bit.y);
      _canvas.rotate(bit.rotation);
      _canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: w * .012, height: w * .022), const Radius.circular(3)), _p);
      _canvas.restore();
    }
    _drawRacket();
    _p.shader = ui.Gradient.radial(Offset(w * ballX - w * .01, h * ballY - w * .01), w * .055,
        [Colors.white, const Color(0xFFF7F5E9), const Color(0xFFCCC9BF)]);
    _canvas.drawCircle(Offset(w * ballX, h * ballY), w * .035, _p);
    _p.shader = null;
    _roundRect(.32, .085, .68, .172, w * .035, dark ? const Color(0xE8201838) : const Color(0xCC174C3A));
    _strokeRoundRect(.32, .085, .68, .172, w * .035, dark ? const Color(0xAA55F2F0) : const Color(0x304DC9A0), math.max(3.0, w * .004).toDouble());
    _text('$score', h * .15, w * .11, const Color(0xFFFFF3C4), bold: true);
    _text('EN İYİ: $best', h * .195, w * .034, ink);
    if (!gameOver && !paused && hintAlpha > 0) {
      _text(kIsWeb ? 'Raketi parmağınla sağa sola sürükle' : (mode == 1 ? 'Top gitgide hızlanıyor!' : 'Ekranın üst kenarını sağa/sola çevir'), h * .24, w * .038, ink, alpha: hintAlpha);
    }
    if (gameOver) {
      final t = gameOverProgress * gameOverProgress * (3 - 2 * gameOverProgress);
      _canvas.save();
      _canvas.translate(0, h * .018 * (1 - t));
      _text('OYUN BİTTİ', h * .405, w * .065, accent, bold: true, alpha: t);
      _text('Skor: $finalScore', h * .46, w * .045, ink, alpha: t);
      _button(.18, .55, .82, .625, 'TEKRAR OYNA', primary: true, alpha: t);
      _button(.18, .655, .82, .73, 'ANA MENÜ', alpha: t);
      _canvas.restore();
    }
    if (paused) {
      _p.color = (dark ? const Color(0xFF101028) : const Color(0xFF123025)).withValues(alpha: .72);
      _canvas.drawRect(Offset.zero & _size, _p);
      _text('DURAKLATILDI', h * .46, w * .075, accent, bold: true);
      _button(.18, .52, .82, .61, 'DEVAM ET', primary: true);
    }
  }

  void _drawRacket() {
    final cx = w * paddleX;
    final cy = h * .84;
    _p.color = Colors.black.withValues(alpha: .25);
    _p.maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
    _canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy + 12), width: w * .3, height: w * .08), _p);
    _p.maskFilter = null;
    _p.color = const Color(0xFF74472C);
    _canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy + w * .065), width: w * .09, height: w * .23), Radius.circular(w * .03)), _p);
    _p.shader = ui.Gradient.linear(Offset(cx - w * .11, cy), Offset(cx + w * .11, cy),
        [const Color(0xFFFF7775), const Color(0xFFE6334B), const Color(0xFFB9163B)]);
    _canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy - w * .015), width: w * .25, height: w * .115), _p);
    _p.shader = null;
    _p.style = PaintingStyle.stroke;
    _p.strokeWidth = math.max(2.0, w * .006).toDouble();
    _p.color = dark ? const Color(0xFFFFB4E1) : const Color(0xFFFFD68A);
    _canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy - w * .015), width: w * .25, height: w * .115), _p);
    _p.style = PaintingStyle.fill;
    _p.color = const Color(0xFFCFAD77);
    _canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy + w * .067), width: w * .085, height: w * .012), Radius.circular(w * .01)), _p);
  }

  void _back() => _button(.08, .055, .29, .105, 'GERİ', small: true);
  void _heading(String value, double y) => _text(value, h * y, w * .075, dark ? const Color(0xFFFF9BD5) : const Color(0xFF145640), bold: true);
  void _label(String value, double y, {bool small = false}) => _text(value, h * y, w * (small ? .033 : .04), ink);

  void _text(String value, double baseline, double fontSize, Color color, {bool bold = false, double alpha = 1}) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(
        color: color.withValues(alpha: alpha), fontSize: fontSize,
        fontFamily: 'sans-serif-rounded', fontWeight: bold ? FontWeight.w700 : FontWeight.w500,
        shadows: [Shadow(color: (dark ? const Color(0xCC080A1F) : const Color(0x99304435)).withValues(alpha: alpha), blurRadius: fontSize * .08, offset: Offset(0, fontSize * .025))],
      )),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      maxLines: 1,
    )..layout(maxWidth: w * .92);
    tp.paint(_canvas, Offset((w - tp.width) / 2, baseline - tp.height));
  }

  void _button(double left, double top, double right, double bottom, String label,
      {bool primary = false, bool selected = false, bool small = false, bool darkPill = false, double alpha = 1}) {
    final rect = Rect.fromLTRB(w * left, h * top, w * right, h * bottom);
    final radius = Radius.circular(math.min(w * .11, rect.height / 2).toDouble());
    Color start, end;
    if (darkPill) {
      start = dark ? const Color(0xDD19152F) : const Color(0xAA174438);
      end = dark ? const Color(0xDD231A3D) : const Color(0xAA0F322B);
    } else if (primary || selected) {
      start = dark ? const Color(0xFFFF88C2) : const Color(0xFFFFE39A);
      end = dark ? const Color(0xFFD93883) : const Color(0xFFE9A92E);
    } else {
      start = dark ? const Color(0xFF38305F) : const Color(0xFF2B5B4A);
      end = dark ? const Color(0xFF191D3A) : const Color(0xFF173A34);
    }
    _p.shader = ui.Gradient.linear(rect.topLeft, rect.bottomRight, [start, end]);
    _p.color = Colors.white.withValues(alpha: alpha);
    _p.maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    _canvas.drawRRect(RRect.fromRectAndRadius(rect, radius), _p);
    _p.maskFilter = null;
    _canvas.drawRRect(RRect.fromRectAndRadius(rect, radius), _p);
    _p.shader = null;
    _p.style = PaintingStyle.stroke;
    _p.strokeWidth = math.max(2.5, w * .0035).toDouble();
    final outline = rect.deflate(_p.strokeWidth * 1.35);
    final edgeColor = selected || primary || darkPill ? accent : (dark ? const Color(0xFF55F2F0) : const Color(0xFF79D5A7));
    _p.color = edgeColor.withValues(alpha: alpha * (primary || selected ? .8 : .95));
    _canvas.drawRRect(RRect.fromRectAndRadius(outline, Radius.circular(math.max(0.0, radius.x - _p.strokeWidth * 1.35).toDouble())), _p);
    _p.style = PaintingStyle.fill;
    final textColor = (primary || selected) ? (dark ? const Color(0xFF271C3E) : const Color(0xFF24382F)) : const Color(0xFFF7F4E9);
    final fontSize = small ? w * .029 : w * (darkPill ? .029 : .043);
    final tp = TextPainter(
      text: TextSpan(text: label, style: TextStyle(fontSize: fontSize, color: textColor.withValues(alpha: alpha), fontFamily: 'sans-serif-rounded', fontWeight: FontWeight.w700)),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
      maxLines: 1,
    )..layout(maxWidth: rect.width * .88);
    tp.paint(_canvas, Offset(rect.center.dx - tp.width / 2, rect.center.dy - tp.height / 2));
  }

  void _roundRect(double l, double t, double r, double b, double radius, Color color) {
    _p.shader = null;
    _p.style = PaintingStyle.fill;
    _p.color = color;
    _canvas.drawRRect(RRect.fromRectAndRadius(_rect(l, t, r, b), Radius.circular(radius)), _p);
  }

  void _strokeRoundRect(double l, double t, double r, double b, double radius, Color color, double width) {
    _p.style = PaintingStyle.stroke;
    _p.strokeWidth = width;
    _p.color = color;
    _canvas.drawRRect(RRect.fromRectAndRadius(_rect(l, t, r, b).deflate(width / 2), Radius.circular(radius)), _p);
    _p.style = PaintingStyle.fill;
  }

  Rect _rect(double l, double t, double r, double b) => Rect.fromLTRB(w * l, h * t, w * r, h * b);

  @override
  bool shouldRepaint(covariant _GamePainter old) => true;
}
